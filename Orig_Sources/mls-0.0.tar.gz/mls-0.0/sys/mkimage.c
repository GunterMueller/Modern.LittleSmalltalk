/*
 * mkimage.c -- main program of MLS image generator
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common.h"
#include "machine.h"
#include "memory.h"
#include "ui.h"
#include "filein.h"
#include "compiler.h"


/**************************************************************/


#define MAX_CLASS_FILES		20	/* max number of class files */


/**************************************************************/


static void createImageFile(char *imageFileName) {
  FILE *imageFile;

  /* try to create image file */
  imageFile = fopen(imageFileName, "wb");
  if (imageFile == NULL) {
    sysError("cannot create image file '%s'", imageFileName);
  }
  /* write initial machine state */
  machine.signature_1 = SIGNATURE_1;
  machine.signature_2 = SIGNATURE_2;
  machine.majorVersion = MAJOR_VNUM;
  machine.minorVersion = MINOR_VNUM;
  machine.memoryStart = sizeof(Machine);
  machine.memorySize = 0;
  if (fwrite(&machine, sizeof(Machine), 1, imageFile) != 1) {
    sysError("cannot write initial machine state");
  }
  /* close image file */
  fclose(imageFile);
}


/**************************************************************/


static void version(char *myself) {
  printf("%s version %d.%d (compiled %s)\n",
         myself, MAJOR_VNUM, MINOR_VNUM, __DATE__);
}


static void help(char *myself) {
  printf("Usage: %s [options] [<class file> <class file> ...]\n", myself);
  printf("Options:\n");
  printf("  --image <image file>    set image file name\n");
  printf("  --memory                show memory statistics\n");
  printf("  --filein                show file-in details\n");
  printf("  --source                show source given to compiler\n");
  printf("  --tokens                show token stream\n");
  printf("  --tree                  show syntax tree\n");
  printf("  --code                  show bytecode\n");
  printf("  --version               show version and terminate\n");
  printf("  --help                  show this help and terminate\n");
}


int main(int argc, char *argv[]) {
  int i;
  char *imageFileName;
  char *classFileName[MAX_CLASS_FILES];
  int numClassFiles;
  FILE *classFile;

  printf("Modern Little Smalltalk %d.%d image generator\n",
         MAJOR_VNUM, MINOR_VNUM);
  imageFileName = DFLT_IMG_NAME;
  numClassFiles = 0;
  for (i = 1; i < argc; i++) {
    if (*argv[i] == '-') {
      /* option */
      if (strcmp(argv[i], "--image") == 0) {
        if (i == argc - 1) {
          sysError("no image file name specified");
        }
        imageFileName = argv[++i];
      } else
      if (strcmp(argv[i], "--memory") == 0) {
        debugMemory = true;
      } else
      if (strcmp(argv[i], "--filein") == 0) {
        debugFileIn = true;
      } else
      if (strcmp(argv[i], "--source") == 0) {
        debugSource = true;
      } else
      if (strcmp(argv[i], "--tokens") == 0) {
        debugTokens = true;
      } else
      if (strcmp(argv[i], "--tree") == 0) {
        debugTree = true;
      } else
      if (strcmp(argv[i], "--code") == 0) {
        debugCode = true;
      } else
      if (strcmp(argv[i], "--version") == 0) {
        version(argv[0]);
        exit(0);
      } else
      if (strcmp(argv[i], "--help") == 0) {
        help(argv[0]);
        exit(0);
      } else {
        sysError("unknown option '%s', try '%s --help'",
                 argv[i], argv[0]);
      }
    } else {
      /* file */
      if (numClassFiles == MAX_CLASS_FILES) {
        sysError("too many class files specified");
      }
      classFileName[numClassFiles++] = argv[i];
    }
  }
  createImageFile(imageFileName);
  initMemory(imageFileName);
  for (i = 0; i < numClassFiles; i++) {
    printf("filing-in '%s'\n", classFileName[i]);
    classFile = fopen(classFileName[i], "r");
    if (classFile == NULL) {
      sysError("cannot open class file '%s'", classFileName[i]);
    }
    if (!fileIn(classFile)) {
      sysError("could not file-in '%s' properly", classFileName[i]);
    }
    fclose(classFile);
  }
  exitMemory(imageFileName);
  printf("Image generated.\n");
  return 0;
}
