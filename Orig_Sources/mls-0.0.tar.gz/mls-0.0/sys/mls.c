/*
 * mls.c -- main program of Modern Little Smalltalk
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common.h"
#include "machine.h"
#include "memory.h"
#include "ui.h"


/**************************************************************/


static void version(char *myself) {
  printf("%s version %d.%d (compiled %s)\n",
         myself, MAJOR_VNUM, MINOR_VNUM, __DATE__);
}


static void help(char *myself) {
  printf("Usage: %s [options]\n", myself);
  printf("Options:\n");
  printf("  --image <image file>    set image file name\n");
  printf("  --memory                show memory statistics\n");
  printf("  --version               show version and terminate\n");
  printf("  --help                  show this help and terminate\n");
}


int main(int argc, char *argv[]) {
  int i;
  char *imageFileName;

  printf("Modern Little Smalltalk %d.%d\n",
         MAJOR_VNUM, MINOR_VNUM);
  imageFileName = DFLT_IMG_NAME;
  for (i = 1; i < argc; i++) {
    if (*argv[i] == '-') {
      /* option */
      if (strcmp(argv[i], "--image") == 0) {
        if (i == argc - 1) {
          sysError("no image file name specified");
        }
        imageFileName = argv[++i];
      } else
      if (strcmp(argv[i], "--memory") == 0) {
        debugMemory = true;
      } else
      if (strcmp(argv[i], "--version") == 0) {
        version(argv[0]);
        exit(0);
      } else
      if (strcmp(argv[i], "--help") == 0) {
        help(argv[0]);
        exit(0);
      } else {
        sysError("unknown option '%s', try '%s --help'",
                 argv[i], argv[0]);
      }
    } else {
      /* file */
      sysError("illegal file argument '%s', try '%s --help'",
               argv[i], argv[0]);
    }
  }
  initMemory(imageFileName);
  exitMemory(imageFileName);
  printf("Bye...\n");
  return 0;
}
