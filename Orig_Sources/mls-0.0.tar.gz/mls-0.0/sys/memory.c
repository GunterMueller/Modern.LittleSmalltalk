/*
 * memory.c -- object memory
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common.h"
#include "machine.h"
#include "memory.h"
#include "ui.h"


/**************************************************************/


Bool debugMemory = false;	/* debug flag, give statistics if set */

static Byte *memory;		/* object memory where all objects live */

static Address toStart;		/* base of "to" semispace in memory */
static Address toEnd;		/* top of "to" semispace in memory */
static Address fromStart;	/* base of "from" semispace in memory */
static Address fromEnd;		/* top of "from" semispace in memory */
static Address toFree;		/* address of first free byte in memory,
				   is always located in "to" semispace */

static Word numBytes;		/* number of bytes allocated since last GC,
				   also number of bytes copied during GC */
static Word numObjects;		/* number of objects allocated since last GC,
				   also number of objects copied during GC */


/**************************************************************/


static void doGC(void) {
  /* print allocation statistics and init collection statistics */
  if (debugMemory) {
    printf("GC: %u bytes in %u objects allocated since last collection\n",
           numBytes, numObjects);
    numBytes = 0;
    numObjects = 0;
  }
  /* ... here the garbage collection takes place ... */
  /* print collection statistics and init allocation statistics */
  if (debugMemory) {
    printf("    %u bytes in %u objects copied during this collection\n",
           numBytes, numObjects);
    printf("    %lu of %lu bytes are now free\n",
           (Address) SEMI_SIZE * sizeof(Byte) - numBytes,
           (Address) SEMI_SIZE * sizeof(Byte));
    numBytes = 0;
    numObjects = 0;
  }
}


static void initGC(void) {
  /* "to" semispace initially starts at 0 */
  toStart = (Address) 0;
  toEnd = toStart + (Address) SEMI_SIZE * sizeof(Byte);
  /* "from" semispace starts where "to" semispace ends */
  fromStart = toEnd;
  fromEnd = fromStart + (Address) SEMI_SIZE * sizeof(Byte);
  /* first free byte depends on how much was loaded */
  toFree = toStart + (Address) machine.memorySize * sizeof(Byte);
  /* init allocation statistics */
  if (debugMemory) {
    numBytes = 0;
    numObjects = 0;
  }
}


static void exitGC(void) {
  /* do a collection to get objects compacted */
  doGC();
  /* check whether in lower semispace */
  if (toStart != (Address) 0) {
    /* it's the upper one, so collect again to switch semispaces */
    doGC();
  }
  /* compute total size of all objects in bytes */
  machine.memorySize = toFree - toStart;
}


/**************************************************************/


void initMemory(char *imageFileName) {
  FILE *imageFile;

  /* allocate object memory */
  memory = malloc(MEMORY_SIZE * sizeof(Byte));
  if (memory == NULL) {
    sysError("cannot allocate object memory");
  }
  /* open image file */
  imageFile = fopen(imageFileName, "rb");
  if (imageFile == NULL) {
    sysError("cannot open image file '%s' for read", imageFileName);
  }
  /* read machine state */
  if (fread(&machine, sizeof(Machine), 1, imageFile) != 1) {
    sysError("cannot read machine state from image file");
  }
  /* check image file signature */
  if (machine.signature_1 != SIGNATURE_1 ||
      machine.signature_2 != SIGNATURE_2) {
    sysError("file '%s' is not an image file", imageFileName);
  }
  /* check image file version number (major only, minor ignored) */
  if (machine.majorVersion != MAJOR_VNUM) {
    sysError("wrong image file version number");
  }
  /* load object memory */
  if (fread(memory, sizeof(Byte), machine.memorySize, imageFile) !=
      machine.memorySize) {
    sysError("cannot read objects from image file");
  }
  /* close image file */
  fclose(imageFile);
  /* init garbage collector */
  initGC();
}


void exitMemory(char *imageFileName) {
  FILE *imageFile;

  /* exit garbage collector */
  exitGC();
  /* open image file */
  imageFile = fopen(imageFileName, "wb");
  if (imageFile == NULL) {
    sysError("cannot open image file '%s' for write", imageFileName);
  }
  /* write machine state */
  if (fwrite(&machine, sizeof(Machine), 1, imageFile) != 1) {
    sysError("cannot write machine state to image file");
  }
  /* save object memory */
  if (fwrite(memory, sizeof(Byte), machine.memorySize, imageFile) !=
      machine.memorySize) {
    sysError("cannot write objects to image file");
  }
  /* close image file */
  fclose(imageFile);
  /* free object memory */
  free(memory);
}
