/*
 * filein.c -- interpret a class file
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common.h"
#include "filein.h"
#include "compiler.h"
#include "ui.h"


#define MAX_TOKENS	(LINE_SIZE / 2)


/**************************************************************/


Bool debugFileIn = false;	/* debug flag, show details if set */


/**************************************************************/


static Bool fileInClassDef(char *line,
                           char *tokens[], int numTokens) {
  int i;

  if (numTokens < 3) {
    sysWarning("%s\ntoo few tokens in line", line);
    return false;
  }
  if (debugFileIn) {
    printf("class definition of '%s' as subclass of '%s'\n",
           tokens[1], tokens[2]);
    if (numTokens > 3) {
      printf("  instvars: ");
      for (i = 3; i < numTokens; i++) {
        printf("%s ", tokens[i]);
      }
      printf("\n");
    }
  }
  return true;
}


static Bool fileInMethods(char *line,
                          char *tokens[], int numTokens,
                          FILE *classFile) {
  char methodLine[LINE_SIZE];
  char methodSource[METHOD_SIZE];
  char *p;
  int n;

  if (numTokens < 3) {
    sysWarning("%s\ntoo few tokens in line", line);
    return false;
  }
  if (debugFileIn) {
    printf("compiling methods for class '%s'\n",
           tokens[1]);
  }
  while (1) {
    /* file-in a single method */
    /* first, get text of method */
    p = methodSource;
    while (1) {
      if (fgets(methodLine, LINE_SIZE, classFile) == NULL) {
        sysWarning("unexpected end of file");
        return false;
      }
      if (methodLine[0] == '|' || methodLine[0] == ']') {
        break;
      }
      n = strlen(methodLine);
      if (n >= &methodSource[METHOD_SIZE] - p) {
        sysWarning("method text too long");
        return false;
      }
      strcpy(p, methodLine);
      p += n;
    }
    /* then, compile method */
    if (!compile(methodSource, 0)) {
      return false;
    }
    if (methodLine[0] == ']') {
      break;
    }
  }
  return true;
}


/**************************************************************/


static int tokenize(char *line, char *tokens[], int maxTokens) {
  int n;
  char *p;

  n = 0;
  p = strtok(line, " \t\r\n");
  while (p != NULL) {
    if (n < maxTokens) {
      tokens[n++] = p;
    }
    p = strtok(NULL, " \t\r\n");
  }
  return n;
}


Bool fileIn(FILE *classFile) {
  char line[LINE_SIZE];
  char *tokens[MAX_TOKENS];
  int n;

  while (fgets(line, LINE_SIZE, classFile) != NULL) {
    n = tokenize(line, tokens, MAX_TOKENS);
    if (n == 0) {
      /* line is empty */
      continue;
    }
    if (strcmp(tokens[0], "*") == 0) {
      /* line is a comment line */
      continue;
    }
    if (strcmp(tokens[0], "Class") == 0) {
      if (!fileInClassDef(line, tokens, n)) {
        return false;
      }
      continue;
    }
    if (strcmp(tokens[0], "Methods") == 0) {
      if (!fileInMethods(line, tokens, n, classFile)) {
        return false;
      }
      continue;
    }
    sysWarning("%s\nunrecognized line", line);
    return false;
  }
  return true;
}
