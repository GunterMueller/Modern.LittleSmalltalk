
#include "trees.h"

int
tr_nchildren(t)
register TREE *t;
{
	register int i = t->focus, hd, n = 0;
	
	if ( i >= t->nobjs ) return -1;
	if ( ( hd= HEAD(i) ) < 0 ) return 0;
	while ( hd != i ) { n++; hd = NEXT(hd); }
	return n;
}

