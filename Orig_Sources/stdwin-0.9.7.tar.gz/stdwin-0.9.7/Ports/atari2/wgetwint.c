
#include "window.h"

void
wgetwintextattr(win, attr)
WINDOW *win;
TEXTATTR *attr;
{
	if ( win != NULL ) *attr = win->attr;
}

