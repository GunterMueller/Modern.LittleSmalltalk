
#include "window.h"

void
wbegindrawing(win)
WINDOW *win;
{
	int left;
	int top;
	int right;
	int bottom;

	if ( drawing != NULL ) wenddrawing(drawing);
	rmcaret ();

	drawing = win;

	extrah = win->h - win->orgh;
	extrav = win->v - win->orgv;

	wgettextattr(&savetextattr);
	wsettextattr(&win->attr);

	if ( !mouseoff ) {
		int	status;
		int	m_h;
		int	m_v;

		vq_mouse(vdi_handle, &status, &m_h, &m_v);

		if (m_h > win->h - 2 * wcharwidth('m') &&
		    m_h < win->h + win->width + 2 * wcharwidth('m') &&
		    m_v > win->v - wlineheight() &&
		    m_v < win->v + win->height + wlineheight() ) {
			mouseoff = TRUE;
			graf_mouse (M_OFF, (MFORM *)0);
		}
	}

	wind_update(BEG_UPDATE);

	left = win->orgh;
	top = win->orgv;
	right = left + win->width;
	bottom = top + win->height;

	setclip(win, 1, left, top, right, bottom);
}

