
#include "window.h"

void
wclose(win)
WINDOW *win;
{
	int	i;
	int	j;
	int	newtop;
	int	dummy = 0;
	int x, y, w, h;

	if (active == win) active = NULL;

	rmcaret();

	for (i = 0; i < nrwin; i++) {
		if (winlist[i] == win) {
/*
			Start with keeping track of the coordinates of the closed
			window so that they can be reused for the next window.
*/
			x = win->h;
			y = win->v;
			w = win->width;
			h = win->height;
			if ( !win->console ) {
				x -= + w_l_border;
				y -= + w_t_border;
				w -= - w_l_border - w_r_border;
			}
			h += w_t_border + w_b_border;
			if ( num_w_pile < MAXWINDOWS ) {
				w_win_pile[num_w_pile].x = x;
				w_win_pile[num_w_pile].y = y;
				w_win_pile[num_w_pile].w = w;
				w_win_pile[num_w_pile].h = h;
				w_win_pile[num_w_pile].console = win->console;
				num_w_pile++;
			}
			else {
				num_w_pile = 0;
				x_def = x; y_def = y; w_def = w; h_def = h;
			}
			if ( !win->title ) w_min_v_pos = 0;
			wind_close(winlist[i]->handle);
			wind_delete(winlist[i]->handle);
			for (j = win->mbar.nrmenus; --j >= 0;)
				wmenudetach(win, win->mbar.menulist[j]);
			L_REMOVE(nrwin, winlist, WINDOW *, i);
			break;
		}
	}

	if (nrwin > 0) {
		wind_get(dummy, WF_TOP, &newtop, &dummy, &dummy, &dummy);
		active = getwin (newtop);
	}
	showcaret ();
}

