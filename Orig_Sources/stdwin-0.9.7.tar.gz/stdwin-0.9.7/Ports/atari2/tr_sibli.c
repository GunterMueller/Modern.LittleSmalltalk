
#include "trees.h"

bool
tr_sibling(t)
register TREE *t;
{
	register int new;
	if (t->nobjs <= 0) return FALSE;
	new = NEXT(t->focus);
	if ( TAIL(new) == t->focus ) return FALSE;
	t->focus = new;
	return TRUE;
}

