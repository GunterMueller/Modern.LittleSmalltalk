
#include "window.h"

int
waskstr(prompt, buf, buflen)
char *prompt;
char *buf;
int buflen;
{
	OBJECT *dialog = str_obj (prompt, buf, buflen);
	int x_tmpbox, y_tmpbox, w_tmpbox, h_tmpbox;
	int rc;

	graf_mouse(ARROW, (MFORM *)0);

	form_center(dialog, &x_tmpbox, &y_tmpbox, &w_tmpbox, &h_tmpbox);
	form_dial(0, 1, 1, 1, 1, x_tmpbox, y_tmpbox, w_tmpbox, h_tmpbox);

	objc_draw(dialog, ROOT, MAX_DEPTH, x_tmpbox, y_tmpbox, w_tmpbox, h_tmpbox);

	rc = form_do(dialog, 3);

	form_dial(3, 1, 1, 1, 1, x_tmpbox, y_tmpbox, w_tmpbox, h_tmpbox);

	graf_mouse(BUSY_BEE, (MFORM *)0);

	if ( rc == 5 ) {	/*	Cancel	*/
		buf[0] = '\0';
		return(FALSE);
	}
	return(TRUE);
}

