#include "window.h"

int     Dgetdrv( void );
int     Dgetpath( char *path, int driveno );

static char	curdir[256];

int
waskfile(prompt, buf, buflen, new)
char *prompt;
char *buf;
int buflen;
int new;
{
	static char dir[256];
	static char fname[256];
	char *p = dir;
	int button;
	int retsel;

	if ( !*dir ) {
		int drive;

		drive = Dgetdrv();
		*p++ = (char) drive + 'A';
		*p++ = ':';
		Dgetpath(p, drive + 1);
		strcat(dir, "\\*.*");
		strcpy(curdir, dir);
	}

	if ( *buf ) {
		char *pdir;

		p = strrchr(buf, '\\');

		if (buf[1] == ':')	/* buf contains full path name */
			pdir = dir;
		else
			pdir = &dir[2];

		if ( p ) {
			strncpy (pdir, buf, (int) (p - buf));
			strcat (dir, "\\*.*");
			strcpy (fname, &buf[(int) (p - buf) + 1]);
		}
		else
			strcpy (fname, buf);
	}

	evnt_dclick(ClickSpeed,1);			/* High Speed */
	retsel = fsel_input (dir, fname, &button);
	evnt_dclick(4,1);			/* High Speed */
	if ( !retsel ) {
		buf[0] = '\0';
		return (FALSE);
	}

	if ( !button ) {
		buf[0] = '\0';
		return (FALSE);
	}

	if ( (p = strrchr (dir, '\\')) == NULL ) p = dir;

	if ( strncmp (curdir, dir, (int) (p - dir)) == 0 ) {
		strcpy (buf, fname);
		return (TRUE);
	}

	if ( buflen < ((int) (p - dir + 1) + strlen (fname)) ) {
		buf[0] = '\0';
		return (FALSE);
	}

	strncpy(buf, dir, (int) (p - dir) + 1);
	buf[(int) (p - dir) + 1] = 0;
	strcat(buf, fname);

	return(TRUE);
}

