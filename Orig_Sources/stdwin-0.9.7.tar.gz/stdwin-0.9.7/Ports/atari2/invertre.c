
#include "window.h"

void
inVertrect(win, left, top, right, bottom)
WINDOW *win;
int left;
int top;
int right;
int bottom;
{
	int area[4];
	
	if ( right <= left || bottom <= top ) return; /* Empty box */

	DOCTOSCR (win, left, top, area[0], area[1]);
	DOCTOSCR (win, right - 1, bottom - 1 , area[2], area[3]);

	if ( curr_interior != 1 ) {
		vsf_interior(vdi_handle, 1);
		curr_interior = 1;
	}
	if ( curr_color != 1 ) {
		vsf_color(vdi_handle, 1);
		curr_color = 1;
	}
	if ( curr_mode != 3 ) {
		vswr_mode(vdi_handle, 3);
		curr_mode = 3;
	}

	vr_recfl(vdi_handle, area);
}

