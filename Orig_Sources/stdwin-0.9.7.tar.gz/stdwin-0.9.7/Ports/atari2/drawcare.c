
#include "window.h"

void
draWcaret(win)
WINDOW *win;
{
    int left;
    int top;
    int right;
    int bottom;

	if ( win->caret_h < 0 || win->caret_v < 0 ) return;

	if ( mouseoff == FALSE ) {
		graf_mouse(M_OFF, (MFORM *)0);
		mouseoff = TRUE;
	}

	setclip (win, 1, win->orgh, win->orgv, win->orgh + win->width,
						win->orgv + win->height);
	left = win->caret_h;
	top = win->caret_v;
	right = win->caret_h + 8;
	bottom = win->caret_v + wlineheight();
	inVertrect(win, left, top, right, bottom);

	setclip(win, 0, win->orgh, win->orgv, win->orgh + win->width,
						win->orgv + win->height);

	graf_mouse(M_ON, (MFORM *)0);
	mouseoff = FALSE;
}

