
struct menubar {
	int	nrmenus ;
	MENU	**menulist ;
} ;

struct ln {
	int	m ;
	int	it ;
} ;

#define BAR	0x0110f0L
#define BOX	0x0ff10f0L
/*	(-1 << 16 | BLACK << 12 | WHITE << 8 | 1 << 7 | 7 << 4 | WHITE)       */

struct key__tab {
	int	id;
	int	item;
} ;

extern struct key__tab keytab[];

extern int	deflocal;
extern struct menubar globmenus;

extern int	barchanged;

extern struct ln m_link[];

extern OBJECT *menu;

