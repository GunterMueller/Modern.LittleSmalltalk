
#include <stdarg.h>
#include "window.h"

void
wdebug (char *fmt, ...)
{
	va_list ap;
	char buf[256];
	va_start(ap,fmt);

	strcpy(buf, "[3][__");
	vsprintf(buf+4, fmt, ap);
	strcat(buf, "__][abort|cont]");

	va_end(ap);

	if (form_alert (2, buf) == 1) {
		wdone();
		exit(1);
	}
}

