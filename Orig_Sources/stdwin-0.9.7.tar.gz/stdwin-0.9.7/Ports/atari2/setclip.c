
#include "window.h"

void
setclip(win, flag, left, top, right, bottom)
WINDOW *win;
int flag;
int left;
int top;
int right;
int bottom;
{
	int scr_rect[4];

	DOCTOSCR(win, left, top, scr_rect[0], scr_rect[1]);
	DOCTOSCR(win, right - 1, bottom - 1, scr_rect[2], scr_rect[3]);

	vs_clip(vdi_handle, flag, scr_rect);
}

