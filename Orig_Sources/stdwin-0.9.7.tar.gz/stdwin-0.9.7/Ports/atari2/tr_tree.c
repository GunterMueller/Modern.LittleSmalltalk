
#include "trees.h"

OBJECT *
tr_tree(t)
TREE *t;
{
	if ( t->nobjs <= 0 ) return (OBJECT *)0;
	t->obj[t->nobjs - 1].ob_flags |= LASTOB;
	return t->obj;
}

