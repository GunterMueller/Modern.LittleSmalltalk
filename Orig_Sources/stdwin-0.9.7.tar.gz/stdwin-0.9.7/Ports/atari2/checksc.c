
#include "window.h"

int getascii(int scan);

/*
	Routine checks for whether we have run into a `shortcut'
*/

void
checksc(ep, key)
EVENT *ep;
int	key;
{
	int	scan = (key & 0xFF00) >> 8;
	int	k = getascii(scan);

	if ( k < 0 || k >= 256 ) return;

	if ( keytab[k].id <= 0 ) k = toupper(k);

	if (keytab[k].id > 0) {
		ep->type = WE_MENU;
		ep->window = active;
		ep->u.m.id = keytab[k].id;
		ep->u.m.item = keytab[k].item;
	}

}

