/* STDWIN -- TEXT ATTRIBUTES. */

#define PLAIN		0x00
#define HILITE		0x01
#define INVERSE		0x02
#define ITALIC		0x04
#define BOLD		0x08
#define UNDERLINE	0x10

extern TEXTATTR wattr;

void setattr(void);
