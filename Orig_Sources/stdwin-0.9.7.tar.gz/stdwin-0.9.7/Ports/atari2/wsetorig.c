
#include "window.h"

void
wsetorigin(win, h, v)
WINDOW *win;
int h;
int v;
{
    int l;
    int t;
    int r;
    int b;
    int dh;
    int dv;
    int src[4];
    int diff[4][4];
    int nr_diff;
    int i;

	if ( win == NULL ) return;

	if ( h > win->doc_width - win->width ) h = win->doc_width - win->width;

	if ( h < 0 ) h = 0;

	if ( v > win->doc_height - win->height ) v = win->doc_height - win->height;

	if ( v < 0 ) v = 0;

	if ( h == win->orgh && v == win->orgv ) return;

	rmcaret();

	l = win->orgh;
	r = win->orgh + win->width;
	t = win->orgv;
	b = win->orgv + win->height;
	dh = win->orgh - h;
	dv = win->orgv - v;

	if (dh > 0)      l -= dh;
	else if (dh < 0) r -= dh;
	if (dv > 0)      t -= dv;
	else if (dv < 0) b -= dv;

	if ( getsrcdiff(win, l, t, r, b, dh, dv, src, diff, &nr_diff) ) {
		scrollby(win, src[0], src[1], src[2], src[3], dh, dv);
	}

	win->orgh = h;
	win->orgv = v;

	for (i = 0; i < nr_diff; i++) {
		wchange(win, diff[i][0], diff[i][1], diff[i][2], diff[i][3]);
	}

	showcaret();

	wupdate (win);

	setscrollbars (win);
}

