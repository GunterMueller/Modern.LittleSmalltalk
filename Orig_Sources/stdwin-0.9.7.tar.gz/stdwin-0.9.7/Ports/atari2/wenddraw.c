
#include "window.h"

void
wenddrawing(win)
WINDOW *win;
{
	int left;
	int top;
	int right;
	int bottom;

	if ( drawing == NULL || drawing != win ) return;

	left = win->orgh;
	top = win->orgv;
	right = left + win->width;
	bottom = top + win->height;

	setclip(win, 0, left, top, right, bottom);

	wind_update(END_UPDATE);

	wsettextattr(&savetextattr);

	extrah = extrav = 0;

	drawing = (WINDOW *) NULL;

	showcaret ();
}

