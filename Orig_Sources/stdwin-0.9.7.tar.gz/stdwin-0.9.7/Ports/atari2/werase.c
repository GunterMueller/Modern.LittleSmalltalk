
#include "window.h"

void
werase(left, top, right, bottom)
int left;
int top;
int right;
int bottom;
{
	int area[4];

	if ( drawing == NULL ) return;
	
	if ( right <= left || bottom <= top ) return; 	/* Empty box */

	area[0] = left + extrah;
	area[1] = top + extrav;
	area[2] = right + extrah - 1;
	area[3] = bottom + extrav - 1;
	
	if ( curr_interior != 1 ) {
		vsf_interior(vdi_handle, 1);
		curr_interior = 1;
	}
	if ( curr_color != 0 ) {
		vsf_color(vdi_handle, 0);
		curr_color = 0;
	}
	if ( curr_mode != 1 ) {
		vswr_mode(vdi_handle, 1);
		curr_mode = 1;
	}

	vr_recfl(vdi_handle, area);
}

