
#include "window.h"

int
wtextwidth(str,len)
char *str;
int len;
{
	int	dummy;
	int	sizes[5];
	int	adjust[3];
	if ( len == -1 ) len = strlen(str);
/*
	The width of one character on the ATARI with a monochrome display
	and default attributes is "w_ch_width" pixels. The only thing we have to
	calculate is the adjustment for the 'special effects'.
*/
	vqt_fontinfo (vdi_handle, &dummy, &dummy, sizes, &dummy, adjust);

	return (len * (w_ch_width + adjust[0]));
}

