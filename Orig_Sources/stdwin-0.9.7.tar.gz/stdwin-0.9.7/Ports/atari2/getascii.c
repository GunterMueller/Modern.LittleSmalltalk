
#include "window.h"

unsigned char **Keytbl(void *,void *,void *);

int
getascii(scan)
int	scan;
{
	static bool	first = TRUE;
	static unsigned char *keycode;

	if ( scan < 0 || scan >= 128 ) return (-1);

	if (first) {
		unsigned char **tbl;
		tbl = Keytbl ((void *)(-1L), (void *)(-1L), (void *)(-1L));
		keycode = tbl[0];
		first = FALSE;
	}

	return((int)(keycode[scan]));
}

