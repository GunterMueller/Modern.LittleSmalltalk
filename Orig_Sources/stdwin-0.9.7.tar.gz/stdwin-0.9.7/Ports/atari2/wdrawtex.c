
#include "window.h"
#include "style.h"

int
wdrawtext(h, v, str, len)
int h;
int v;
char *str;
int len;
{
	TEXTATTR attr;
	int scr_h;
	int scr_v;
	int save;
	char *s;
	if ( len == -1 ) {
		s = str; while ( *s ) s++;
		len = s - str;
	}
	else s = str + len;

	if (drawing == NULL) return (h);

	wgettextattr(&attr);

	if (curr_mode != 1) {
		vswr_mode (vdi_handle, 1);
		curr_mode = 1;
	}

	scr_h = h + extrah;
	scr_v = v + extrav;

	save = *s;
	*s = 0;

/*
	v_gtext(vdi_handle, scr_h, scr_v, str);
*/
	v_mtext(vdi_handle, scr_h, scr_v, str, len);

	*s = save;

	if (attr.style & INVERSE) {
		int	left = h;
		int	top = v;
		int	right;
		int	bottom;

		right = h + wtextwidth(str, len);
		bottom = v + wlineheight();
	
		winvert(left, top, right, bottom);
	}

	return(h + wtextwidth(str, len));
}

