
#include "window.h"

void
scrollby(win, left, top, right, bottom, dh, dv)
WINDOW	*win;
int	left, top, right, bottom;
int	dh;
int	dv;
{
	MFDB	dummy = { 0L, 0, 0, 0, 0, 0, 0, 0, 0 };
	int	logic = 3;
	int	xyarray[8];
	bool mouseoff = FALSE;
	int	status;
	int	m_h;
	int	m_v;

	DOCTOSCR (win, left, top, xyarray[0], xyarray[1]);
	DOCTOSCR (win, right - 1, bottom - 1, xyarray[2], xyarray[3]);

	DOCTOSCR (win, left + dh, top + dv, xyarray[4], xyarray[5]);
	DOCTOSCR (win, right + dh - 1, bottom + dv - 1, xyarray[6], xyarray[7]);

	vq_mouse (vdi_handle, &status, &m_h, &m_v);

	if (m_h > win->h - wlineheight () &&
	    m_h < win->h + win->width + wlineheight () &&
	    m_v > win->v - 2 * wcharwidth ('m') &&
	    m_v < win->v + win->height + 2 * wcharwidth ('m')) {
		if ( !mouseoff ) {
			mouseoff = TRUE;
			graf_mouse (M_OFF, (MFORM *)0);
		}
	}

	wind_update (BEG_UPDATE);

	setclip (win, 1, win->orgh, win->orgv, win->orgh + win->width,
						win->orgv + win->height);

	vro_cpyfm (vdi_handle, logic, xyarray, &dummy, &dummy);

	setclip (win, 0, win->orgh, win->orgv, win->orgh + win->width,
						win->orgv + win->height);

	wind_update (END_UPDATE);

	if (mouseoff) graf_mouse (M_ON, (MFORM *)0);
}

