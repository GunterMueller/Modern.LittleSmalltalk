
#include "window.h"

void
wupdate(win)
WINDOW *win;
{
	int handle;
	int changed[4];
	int draw[4];
	if ( win == NULL || win->needupdate == 0 ) return;
	
	wgetchange(win, &changed[0], &changed[1], &changed[2], &changed[3]);

	handle = win->handle;
	if ( !wind_get(handle, WF_FIRSTXYWH, &draw[0], &draw[1],
						&draw[2], &draw[3]) ) return;
	while( draw[2] && draw[3] ) {
		SCRTODOC(win, draw[0], draw[1], draw[0], draw[1]);
		draw[2] += draw[0];
		draw[3] += draw[1];

		if ( intersect(changed, draw) ) {
			wbegindrawing(win);
			setclip(win, 1, draw[0], draw[1], draw[2], draw[3]);

			if ( !w_no_erase ) werase(draw[0], draw[1], draw[2], draw[3]);

			if ( win->drawproc != NULL )
				(*win->drawproc)(win, draw[0], draw[1],
						draw[2],draw[3]);
			setclip(win, 0, draw[0], draw[1], draw[2],
							draw[3]);
			wenddrawing (win);
		}
		if ( !wind_get(handle, WF_NEXTXYWH, &draw[0], &draw[1],
						&draw[2], &draw[3]) ) return;
	}
	win->needupdate = FALSE;
}

