
#include "window.h"

bool
getsrcdiff(win, left, top, right, bottom, dh, dv, snit, diff, nr_diff)
WINDOW	*win;
int	left, top, right, bottom;
int	dh;
int	dv;
int	*snit;
int	diff[][4];
int	*nr_diff;
{
	int	src[4];
	int	orgh = win->orgh;
	int	orgv = win->orgv;
	int	width = win->width;
	int	height = win->height;
	src[0] = left;
	src[1] = top;
	src[2] = right;
	src[3] = bottom;

	if (dh > 0) src[2] -= dh;
	else if (dh < 0) src[0] -= dh;

	if (dv > 0) src[3] -= dv;
	else if (dv < 0) src[1] -= dv;
/*
	Clip the rectangle with the window to get the clean source ...
*/
	snit[0] = orgh;
	snit[1] = orgv;
	snit[2] = orgh + width;
	snit[3] = orgv + height;
	if ( !intersect(src, snit) ) {
		*nr_diff = 1;
		diff[0][0] = orgh - dh;
		diff[0][1] = orgv - dv;
		diff[0][2] = orgh + width - dh;
		diff[0][3] = orgv + height - dv;

		return (FALSE);
	}
	rectsubt(src, snit, diff, nr_diff);

	return (TRUE);
}

