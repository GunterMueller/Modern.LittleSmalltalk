
#include "window.h"

void
wmenuenable(pm, item, flag)
void *pm;
int item;
bool flag;
{
	struct m_item *it;

	if ( item < 0 || item >= ((MENU *)pm)->nritems ) return;

	it = ((MENU *)pm)->itemlist[item];

	if ( it->enabled == flag ) return;

	it->enabled = flag;

	if ( menu != NULL ) {
		int	obj = 4;
		int	i;

		for (i = 0; i < active->mbar.nrmenus; ++i) {
			MENU	*mp = active->mbar.menulist[i];

			if ( ((MENU *)pm) == mp ) break;

			obj += mp->nritems + 1;
		}

		obj += item + 1 + active->mbar.nrmenus;
		menu_ienable(menu, obj, it->enabled);
	}
}

