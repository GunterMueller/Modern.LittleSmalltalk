
#include "window.h"

void
addtoall(pm)
void *pm;
{
	int	i;

	addtobar (&globmenus, pm);

	for (i = 0; i < nrwin; i++) wmenuattach(winlist[i], pm);
}

