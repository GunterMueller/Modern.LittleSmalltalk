
#include "window.h"

void
showcaret()
{
	WINDOW *win = active;

	if ( win != NULL && win->caret_h >= 0 && win->caret_v >= 0 && !win->careton ) {
		draWcaret(win);
		win->careton = TRUE;
	}
}

