/* Includes */
#include "stdwdefi.h"

#ifdef BOTH_X11_ALFA

bool both_x11_alfa = 1; /* 1 for x11, 0 for alfa */

void
winitargs(pargc, pargv)
        int *pargc;
        char ***pargv;
{
        extern void x11_winitargs();
        x11_winitargs(pargc, pargv);
}

void
winit()
{
        extern void x11_winit();
        /* sets both_x11_alfa = 0 and calls alfa_winit() if unsuccessful. */
        x11_winit();
}

#endif
