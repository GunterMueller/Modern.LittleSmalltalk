/* Simplified Cut Buffer Interface */

#include "stdwdefi.h"
#include "stdwin.h"

void
wsetclip(data, len)
        char *data;
        int len;
{
        wrotatecutbuffers(1);
        wsetcutbuffer(0, data, len);
}

char *
wgetclip()
{
        int len;
        return wgetcutbuffer(0, &len);
}
