/*
 * tree.h -- abstract syntax tree
 */


#ifndef _TREE_H_
#define _TREE_H_


typedef enum {
  Int, Float, Char, String
} NodeType;

typedef struct {
  NodeType type;
  int line;
  union {
    struct {
      int val;
    } intNode;
    struct {
      double val;
    } floatNode;
    struct {
      char val;
    } charNode;
    struct {
      char *val;
    } stringNode;
  } u;
} Node;


Node *newIntNode(int line, int val);
Node *newFloatNode(int line, double val);
Node *newCharNode(int line, char val);
Node *newStringNode(int line, char *val);

void showTree(Node *tree);


#endif /* _TREE_H_ */
