/*
 * memory.h -- object memory
 */


#ifndef _MEMORY_H_
#define _MEMORY_H_


extern Bool debugMemory;	/* debug flag, give statistics if set */


void initMemory(char *imageFileName);
void exitMemory(char *imageFileName);


#endif /* _MEMORY_H_ */
