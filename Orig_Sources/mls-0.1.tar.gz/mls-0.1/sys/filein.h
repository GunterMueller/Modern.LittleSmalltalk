/*
 * filein.h -- interpret a class file
 */


#ifndef _FILEIN_H_
#define _FILEIN_H_


extern Bool debugFileIn;	/* debug flag, show details if set */


Bool fileIn(FILE *classFile);


#endif /* _FILEIN_H_ */
