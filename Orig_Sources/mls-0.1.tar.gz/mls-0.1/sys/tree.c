/*
 * tree.c -- abstract syntax tree
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common.h"
#include "utils.h"
#include "tree.h"
#include "ui.h"


/**************************************************************/


Node *newIntNode(int line, int val) {
  Node *node;

  node = allocate(sizeof(Node));
  node->type = Int;
  node->line = line;
  node->u.intNode.val = val;
  return node;
}


Node *newFloatNode(int line, double val) {
  Node *node;

  node = allocate(sizeof(Node));
  node->type = Float;
  node->line = line;
  node->u.floatNode.val = val;
  return node;
}


Node *newCharNode(int line, char val) {
  Node *node;

  node = allocate(sizeof(Node));
  node->type = Char;
  node->line = line;
  node->u.charNode.val = val;
  return node;
}


Node *newStringNode(int line, char *val) {
  Node *node;

  node = allocate(sizeof(Node));
  node->type = String;
  node->line = line;
  node->u.stringNode.val = val;
  return node;
}


/**************************************************************/


static void indent(int n) {
  int i;

  for (i = 0; i < n; i++) {
    printf("  ");
  }
}


static void say(char *s) {
  printf("%s", s);
}


static void sayInt(int i) {
  printf("%d", i);
}


static void sayFloat(double d) {
  printf("%e", d);
}


static void sayChar(char c) {
  printf("%c", c);
}


static void showNode(Node *node, int indent);


static void showIntNode(Node *node, int n) {
  indent(n);
  say("Int(");
  sayInt(node->u.intNode.val);
  say(")");
}


static void showFloatNode(Node *node, int n) {
  indent(n);
  say("Float(");
  sayFloat(node->u.floatNode.val);
  say(")");
}


static void showCharNode(Node *node, int n) {
  indent(n);
  say("Char(");
  sayChar(node->u.charNode.val);
  say(")");
}


static void showStringNode(Node *node, int n) {
  indent(n);
  say("String(");
  say(node->u.stringNode.val);
  say(")");
}


static void showNode(Node *node, int indent) {
  if (node == NULL) {
    sysError("node pointer is NULL in showNode");
  } else
  switch (node->type) {
    case Int:
      showIntNode(node, indent);
      break;
    case Float:
      showFloatNode(node, indent);
      break;
    case Char:
      showCharNode(node, indent);
      break;
    case String:
      showStringNode(node, indent);
      break;
    default:
      sysError("unknown node type %d in showNode", node->type);
      break;
  }
}


void showTree(Node *tree) {
  showNode(tree, 0);
  printf("\n");
}
