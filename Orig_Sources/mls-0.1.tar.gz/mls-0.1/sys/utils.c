/*
 * utils.c -- utility functions
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "common.h"
#include "utils.h"
#include "ui.h"


void *allocate(unsigned int size) {
  void *p;

  p = malloc(size);
  if (p == NULL) {
    sysError("out of memory");
  }
  return p;
}


void release(void *p) {
  if (p == NULL) {
    sysError("NULL pointer detected in release");
  }
  free(p);
}
