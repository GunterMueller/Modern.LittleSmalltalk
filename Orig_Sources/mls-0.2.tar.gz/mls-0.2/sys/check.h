/*
 * check.h -- semantic checks
 */


#ifndef _CHECK_H_
#define _CHECK_H_


void check(Node *method, ObjPtr class);
void showVariables(void);
void freeVariables(void);


#endif /* _CHECK_H_ */
