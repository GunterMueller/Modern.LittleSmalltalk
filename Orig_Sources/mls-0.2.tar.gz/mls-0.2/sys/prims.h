/*
 * prims.h -- the primitives
 */


#ifndef _PRIMS_H_
#define _PRIMS_H_


void primitive(int numArgs, int primNum);


#endif /* _PRIMS_H_ */
