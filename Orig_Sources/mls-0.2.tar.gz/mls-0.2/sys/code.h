/*
 * code.h -- code generator
 */


#ifndef _CODE_H_
#define _CODE_H_


void code(char *text, Node *method, ObjPtr class, Bool valueNeeded);
void showCode(void);


#endif /* _CODE_H_ */
